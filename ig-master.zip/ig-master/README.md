
Cara install Tool Instagram dengan Aplikasi Termux

	 git https://github.com/kumpulanremaja/ig/
	 cd ig
	 unzip node_modules.zip
	 ls
	 Then select the tool you want to use!
	node filename
	
	untuk selengkapnya bisa baca tutoria di https://www.kumpulanremaja.com/2019/04/menambah-follower-instagram-dengan-termux.html


